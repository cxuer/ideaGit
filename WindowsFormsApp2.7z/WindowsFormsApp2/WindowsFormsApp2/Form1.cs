﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class myCase : Form
    {
        private CaseService service = new CaseService();
        private Case testCase = new Case();
        private int index = 0;
        private int couts = 0;
        public myCase()
        {
            InitializeComponent();
        }

        private void impExcleToolStripMenuItem_Click(object sender, EventArgs e)
        {
            service = new CaseService();
            testCase = new Case();
            this.service.readExcelFile();
            couts = service.getSize() - 1;
            showCaseInfo();
        }

        private void exitMenuItem_Click(object sender, EventArgs e)
        {
            //this.Close();
            System.Environment.Exit(0);

        }

        private void aboutMenuItem_Click(object sender, EventArgs e)
        {
            showHelp();
        }

        private void showHelp()
        {
            StringBuilder builder = new StringBuilder();

            builder.Append("Welcome to use myCase!" + "\n");
            builder.Append("release 1.04.12.2018" + "\n\n\n");
            builder.Append("There is no executable test case now." + "\n");
            builder.Append("Please import the test case frist." + "\n");
            builder.Append("According to the following steps:" + "\n");
            builder.Append("myCase -> ImpExcel");
            this.caseText.Text = builder.ToString();
        }

        private void showCaseInfo()
        {
            if (couts == 0 || index < 0 || index > couts)
            {
                showHelp();
                MessageBox.Show("import the test case frist.");
            }
            else
            {
                testCase = service.getCase(index);
                StringBuilder builder = new StringBuilder();
                builder.Append("【预置条件】\n").Append(testCase.getCondition());
                builder.Append("\n【测试数据】\n").Append(testCase.getData());
                builder.Append("\n【测试步骤】\n");
                List<string> steps = testCase.getSteps();
                foreach (string s in steps)
                {
                    builder.Append(s + "\n");
                }
                builder.Append("【预期结果】\n").Append(testCase.getExt());
                builder.Append("\n\n" + testCase.getTitle());
 
                //builder.Append("\nindex " + index + " -> (" + couts + ") ");
                this.caseText.Text = builder.ToString();
                this.CountStatus.Text = " [ "+index + " => " + couts+" ]";
            }
            this.caseText.ReadOnly = true;
        }

        private void next_Click(object sender, EventArgs e)
        {
            index++;
            if (index > couts)
            {
                index = couts;
            }
            showCaseInfo();
        }

        private void previous_Click(object sender, EventArgs e)
        {
            index--;
            if (index < 0)
            {
                index = 0;
            }
            showCaseInfo();

        }

        private void myCase_Load(object sender, EventArgs e)
        {
            this.Text = "myCase";
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = true;
            //this.TopLevel = true;
            this.BringToFront();
            this.TopMost = true;
            this.StartPosition = FormStartPosition.CenterParent;
            //this.TimeStatus.Text = "Shiyc all rights reserved";
            this.CountStatus.Text = "";
            showHelp();
            System.Timers.Timer t = new System.Timers.Timer(1000);   //实例化Timer类，设置间隔时间为10000毫秒；   
            t.Elapsed += new System.Timers.ElapsedEventHandler(theout); //到达时间的时候执行事件；   
            t.AutoReset = true;   //设置是执行一次（false）还是一直执行(true)；   
            t.Enabled = true;     //是否执行System.Timers.Timer.Elapsed事件
            this.caseText.ReadOnly = true;
        }
        public void theout(object source, System.Timers.ElapsedEventArgs e)
        {
            this.TimeStatus.Text = DateTime.Now.ToLocalTime().ToString();
            //this.CountStatus.Text = DateTime.Now.ToLocalTime().ToString();
        }

        private void bug_Click(object sender, EventArgs e)
        {
            StringBuilder builder = new StringBuilder();
            builder.Append("【预置条件】\n").Append(testCase.getCondition());
            builder.Append("\n【测试数据】\n").Append(testCase.getData());
            builder.Append("\n【测试步骤】\n");
            List<string> steps = testCase.getSteps();
            if (steps != null && steps.Count > 0)
            {
                foreach (string s in steps)
                {
                    builder.Append(s + "\n");
                }
            }
            builder.Append("【预期结果】\n").Append(testCase.getExt());
            builder.Append("\n【实际结果】\n" + testCase.getTitle());
            builder.Append("\n\n【测试备注】\n" + DateTime.Now.ToLocalTime().ToString());
            this.caseText.Text = builder.ToString();
            //caseText.BackColor=Color.AliceBlue;
            this.caseText.ReadOnly = false;
        }

        private void caseText_Click(object sender, EventArgs e)
        {
            caseText.Focus();
            SendKeys.Send("^c");//复制
            //MessageBox.Show(caseText.SelectedText);
        }
    }
}
