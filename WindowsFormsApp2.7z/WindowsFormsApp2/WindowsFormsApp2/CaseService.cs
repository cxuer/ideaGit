﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace WindowsFormsApp2
{
    class CaseService
    {
        private List<Case> cases = new List<Case>();

        public Case getCase(int index)
        {
            if (getSize()==0) {
                return new Case();
            }
            return cases[index];
        }

        public int getSize()
        {
            if (cases != null)
            {
                return cases.Count;
            }
            return 0;
        }
        public void readExcelFile()
        {
            for (int i = 0; i < 20; i++)
            {
                List<string> list = new List<string>();
                for (int j = 0; j < 5; j++)
                {

                    list.Add("step+" + i);
                }
                Case cs = new Case();
                cs.setCondition("预置条件" + i);
                cs.setData("data" + i);
                cs.setTitle("title" + i);
                cs.setSteps(list);
                cs.setExt("ext");
                cases.Add(cs);
            }
            /*OpenFileDialog filelog = new OpenFileDialog();
            filelog.InitialDirectory = "C:\\";
            filelog.Filter = "Excel文件|*.xlsx";
            filelog.RestoreDirectory = true;
            filelog.FilterIndex = 1;
            if (filelog.ShowDialog() == DialogResult.OK)
            {

                MessageBox.Show(filelog.FileName);
            }*/


        }

        private void openExcelFile()
        {

        }
    }
}
