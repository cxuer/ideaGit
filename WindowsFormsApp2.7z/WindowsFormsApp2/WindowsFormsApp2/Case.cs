﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp2
{
    class Case
    {
        int id;
        string condition;
        string data;
        string title;
        List<string> steps;
        string ext;
        public Case()
        {
        }
        public int getId()
        {
            return id;
        }

        public String getCondition()
        {
            return condition;
        }

        public String getData()
        {
            return data;
        }

        public String getTitle()
        {
            return title;
        }

        public List<String> getSteps()
        {
            return steps;
        }

        public String getExt()
        {
            return ext;
        }

        public void setId(int id)
        {
            this.id = id;
        }

        public void setCondition(String condition)
        {
            this.condition = condition;
        }

        public void setData(String data)
        {
            this.data = data;
        }

        public void setTitle(String title)
        {
            this.title = title;
        }

        public void setSteps(List<String> steps)
        {
            this.steps = steps;
        }

        public void setExt(String ext)
        {
            this.ext = ext;
        }

        public string toSring()
        {
            return "Case{" +
                    "id=" + id +
                    ", condition='" + condition + '\'' +
                    ", data='" + data + '\'' +
                    ", title='" + title + '\'' +
                    ", steps=" + steps +
                    ", ext='" + ext + '\'' +
                    '}';
        }
    }
}
