package com.shiyc.app;


import java.text.ParseException;
import java.util.*;

public class ActivityService {
    private Word word;
    private LinkedList<Word> linkedList;
    private MainRepository repository;

    public ActivityService() {
        this.repository = new MainRepository();
    }

    public Word getWord() {
        if (isEmptyWordList()) {
            intervalWords();
        }
        return word = linkedList.removeFirst();
    }

    private boolean isEmptyWordList() {
        return linkedList == null || linkedList.isEmpty();
    }

    private void intervalWords() {
        linkedList = todayWords();
        if (isEmptyWordList()) {
            linkedList = repository.intervalVocabularies();
        }
    }

    private LinkedList<Word> todayWords() {
        return repository.todayVocabularies();
    }

    public void markInterval(Word interval) {
        interval.setInterval(Dictionaries.DATE_FORMAT.format(new Date().getTime()));
        repository.markInterval(interval);
        if (Dictionaries.MARK_FORGET.equals(interval.getMark())
                || Dictionaries.MARK_QUESTION.equals(interval.getMark())) {
            markReview(interval);
            linkedList.addLast(interval);
        }
    }

    private void markReview(Word review) {
        try {
            long interval = Dictionaries.DATE_FORMAT.parse(review.getInterval()).getTime();
            for (Map.Entry<Long, String> entry : Dictionaries.REVIEWS.entrySet()) {
                if (interval > entry.getKey()) {
                    review.setReview(entry.getValue());
                    break;
                }
            }
            repository.reviewRecord(review);
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }
}
