package com.shiyc.app;

public class Word {
    private Integer id;
    private String name;
    private String interval;
    private String mark;
    private String review;
    private String example;
    private String explanation;
    private String enunciation;
    private String mp3;
    private Integer mp3id;

    public Word() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInterval() {
        return interval;
    }

    public void setInterval(String interval) {
        this.interval = interval;
    }

    public String getMark() {
        return mark;
    }

    public void setMark(String mark) {
        this.mark = mark;
    }

    public String getReview() {
        return review;
    }

    public void setReview(String review) {
        this.review = review;
    }

    public String getExample() {
        return example;
    }

    public void setExample(String example) {
        this.example = example;
    }

    public String getExplanation() {
        return explanation;
    }

    public void setExplanation(String explanation) {
        this.explanation = explanation;
    }

    public String getEnunciation() {
        return enunciation;
    }

    public void setEnunciation(String enunciation) {
        this.enunciation = enunciation;
    }

    public String getMp3() {
        return mp3;
    }

    public void setMp3(String mp3) {
        this.mp3 = mp3;
    }

    public Integer getMp3id() {
        return mp3id;
    }

    public void setMp3id(Integer mp3id) {
        this.mp3id = mp3id;
    }

    @Override
    public String toString() {
        return "Word{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", interval='" + interval + '\'' +
                ", mark='" + mark + '\'' +
                ", review='" + review + '\'' +
                ", example='" + example + '\'' +
                ", explanation='" + explanation + '\'' +
                ", enunciation='" + enunciation + '\'' +
                ", mp3='" + mp3 + '\'' +
                ", mp3id=" + mp3id +
                '}';
    }
}
