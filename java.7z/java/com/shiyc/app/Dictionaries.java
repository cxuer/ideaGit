package com.shiyc.app;

import java.text.SimpleDateFormat;
import java.util.HashMap;

public class Dictionaries {

    public static final String DBNAME = "sqlitedb.db";
    public static final String DBPATH = "/data/data/com.shiyc.app/databases/";
    public static final String DBFILE = "/data/data/com.shiyc.app/databases/sqlitedb.db";
    public static final String MARK_FORGET = "1001";
    public static final String MARK_QUESTION = "1002";
    public static final String MARK_REALIZE = "1003";
    public static final String DATA_LIMIT = "30";
    public static final int MAX_STREAMS = 30;
    public static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    public static final HashMap<Long, String> REVIEWS = new HashMap<Long, String>() {
        {
            put(30000L, "thirtySeconds");
            put(60000L, "oneMinute");
            put(300000L, "fiveMinutes");
            put(1800000L, "thirtyMinutes");
            put(3600000L, "oneHour");
            put(28800000L, "eightHours");
            put(86400000L, "oneDay");
            put(172800000L, "twoDays");
            put(518400000L, "sixDays");
            put(2678400000L, "thirty-oneDays");
        }
    };
}
