package com.shiyc.app;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.provider.UserDictionary;

import java.util.LinkedList;
import java.util.List;

public class MainRepository {

    private SQLiteDatabase database;
    private LinkedList<Word> vocabularies;
    private boolean INIT_TAG = false;
    private final String INNER_JOIN_SQL =
            "select wt.id,wt.name,wt.enunciation,wt.explanation,wt.example,"
                    + "it.mark,it.interval,it.creation "
                    + "from word_t wt inner join interval_t it on wt.id=it.wd ";

    public MainRepository() {
        initialization();
    }

    public LinkedList<Word> todayVocabularies() {
        if (!INIT_TAG) {
            initEveryDay();
        }
        String daySql = INNER_JOIN_SQL + " where date(it.creation) = date(?,?) and it.mark is null limit ?";
        cursorToList(openSqlite().rawQuery(daySql,
                new String[]{"now", "localtime", Dictionaries.DATA_LIMIT}));
        return vocabularies;
    }

    public LinkedList<Word> intervalVocabularies() {
        String preSql = INNER_JOIN_SQL + " order by it.interval,it.mark limit ?";
        cursorToList(openSqlite().rawQuery(preSql, new String[]{Dictionaries.DATA_LIMIT}));
        return vocabularies;
    }

    private void cursorToList(Cursor rs) {
        vocabularies = new LinkedList<>();
        // select wt.id,wt.name,wt.enunciation,wt.explanation,wt.example, it.mark,it.interval,it.creation
        while (rs.moveToNext()) {
            Word word = new Word();
            word.setId(rs.getInt(rs.getColumnIndex("id")));
            word.setName(rs.getString(rs.getColumnIndex("name")));
            word.setEnunciation(rs.getString(rs.getColumnIndex("enunciation")));
            word.setExplanation(rs.getString(rs.getColumnIndex("explanation")));
            word.setExample(rs.getString(rs.getColumnIndex("example")));
            word.setMark(rs.getString(rs.getColumnIndex("mark")));
            word.setInterval(rs.getString(rs.getColumnIndex("interval")));
            word.setMp3(rs.getString(rs.getColumnIndex("name")).trim() + ".mp3");
            vocabularies.addLast(word);
        }
        rs.close();
        closeSqlite();
    }

    public void markInterval(Word word) {
        String intervalSql = "update interval_t set mark = ?,interval = datetime(?) where wd = ?";
        openSqlite().execSQL(intervalSql,
                new String[]{word.getMark(), word.getInterval(), word.getId().toString()});
        closeSqlite();
    }

    public void reviewRecord(Word word) {

    }

    private void initEveryDay() {
        String initSql = "insert into interval_t(wd,creation) "
                + "select id,datetime('now', 'localtime') as creation from word_t "
                + "where not exists (select * from interval_t where word_t.id = interval_t.wd) "
                + "and (select count(*) from interval_t where date(creation) = date('now','localtime')) <= 90 limit 90";
        openSqlite().execSQL(initSql);
        closeSqlite();
        INIT_TAG = true;
    }

    private void initialization() {
        database = SQLiteDatabase.openOrCreateDatabase(Dictionaries.DBFILE, null);
    }

    private SQLiteDatabase openSqlite() {
        if (!database.isOpen()) {
            initialization();
        }
        return database;
    }

    private void closeSqlite() {
        if (database != null && database.isOpen()) {
            database.close();
        }
    }
}
