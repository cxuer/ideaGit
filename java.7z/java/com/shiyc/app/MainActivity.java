package com.shiyc.app;

import android.Manifest;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.io.*;

public class MainActivity extends AppCompatActivity {

    private TextView enunciation;
    private TextView explanation;
    private TextView example;
    private Button realize;
    private Button forgot;
    private Button question;
    private Button follow;
    private SoundPool soundPool;
    private Word activityWord;
    private ActivityService activityService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //检查权限
        checkPermission();
        //复制数据文件
        isExist();
        //初始化控件,注册事件
        findViews();
        initSoundPool();
        onClickListener(realize);
        onClickListener(question);
        onClickListener(forgot);
        playMp3();
        activityService = new ActivityService();
        showActivityWord();
    }

    private void playMp3() {
        follow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    activityWord.setMp3id(soundPool.load(getAssets().openFd(activityWord.getMp3()), 1));
                    soundPool.setOnLoadCompleteListener(new SoundPool.OnLoadCompleteListener() {
                        @Override
                        public void onLoadComplete(SoundPool soundPool, int i, int i2) {
                            // soundID(声音id),leftVolume(左声道),rightVolume(右声道),priority(优先级),
                            // loop(0表示不循环，-1表示循环播放), rate(播放比率，0.5~2，一般为1)
                            soundPool.play(activityWord.getMp3id(), 1, 1, 1, 0, 1);
                        }
                    });
                } catch (IOException e) {
                    return;
                }
            }
        });
    }

    private void showActivityWord() {
        activityWord = activityService.getWord();
        setTitle(activityWord.getName());
        enunciation.setText(activityWord.getEnunciation());
        explanation.setText(activityWord.getExplanation());
        example.setText(activityWord.getInterval());
    }

    private void initSoundPool() {
        if (soundPool == null) {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
                AudioAttributes audioAttributes = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build();
                soundPool = new SoundPool.Builder()
                        .setMaxStreams(Dictionaries.MAX_STREAMS)
                        .setAudioAttributes(audioAttributes)
                        .build();
            } else {
                soundPool = new SoundPool(Dictionaries.MAX_STREAMS, AudioManager.STREAM_MUSIC, 0);
            }
        }
    }

    private void onClickListener(View view) {
        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.realize:
                        activityWord.setMark(Dictionaries.MARK_REALIZE);
                        break;
                    case R.id.question:
                        activityWord.setMark(Dictionaries.MARK_QUESTION);
                        break;
                    case R.id.forgot:
                        activityWord.setMark(Dictionaries.MARK_FORGET);
                        break;
                    default:
                        break;
                }
                activityService.markInterval(activityWord);
                showActivityWord();
            }
        });
    }

    private void findViews() {
        enunciation = findViewById(R.id.enunciation);
        explanation = findViewById(R.id.explanation);
        example = findViewById(R.id.example);
        example.setMovementMethod(ScrollingMovementMethod.getInstance());
        realize = findViewById(R.id.realize);
        forgot = findViewById(R.id.forgot);
        question = findViewById(R.id.question);
        follow = findViewById(R.id.follow);
    }

    private void checkPermission() {
        //2.检查权限是否存在
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            //3.向用户申请授权
            ActivityCompat.requestPermissions(this, new String[]{
                    Manifest.permission.WRITE_EXTERNAL_STORAGE,
                    Manifest.permission.READ_EXTERNAL_STORAGE
            }, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(
            int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        //4.用户授权完后回调
        if (requestCode == 1) {
            if (grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {

            } else {

            }
        }
    }

    private void isExist() {
        if (!(new File(Dictionaries.DBFILE)).exists()) {
            File f = new File(Dictionaries.DBPATH);
            if (!f.exists()) {
                f.mkdir();
            }
            try {
                InputStream is = getBaseContext().getAssets().open(Dictionaries.DBNAME);
                OutputStream os = new FileOutputStream(Dictionaries.DBFILE);
                byte[] buffer = new byte[1024];
                int length;
                while ((length = is.read(buffer)) > 0) {
                    os.write(buffer, 0, length);
                }
                os.flush();
                os.close();
                is.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
