using NUnit.Framework;
using Models;
using BLL;


namespace NUnitTestProject
{
    public class Tests
    {
        [SetUp]
        public void Setup()
        {
        }

        [Test]
        public void Test1()
        {
            User u = new User();
            u.name = "123";
            u.pwd = "456";

            Assert.Pass();
        }
    }
}