﻿using System;
using System.Windows.Forms;
using Models;
using BLL;
using System.Collections.Generic;

namespace WindowsFormsApp1
{
    public partial class MyCore : Form
    {
        public MyCore()
        {
            InitializeComponent();
        }

        UserManager manager = new UserManager();

        private void loginBtn_Click(object sender, EventArgs e)
        {
            User user = new User();
            user.name = textName.Text;
            user.pwd = textPwd.Text;
            bool login = manager.Login(user);
            if (login)
            {
                MessageBox.Show("secsessfull!");
            }
            else
            {
                MessageBox.Show("fail!");
            }
        }

        List<User> list = new List<User>();
        private void MyCore_Load(object sender, EventArgs e)
        {
            list = manager.GetUsers();
            /*for (int i = 30 - 1; i >= 0; i--)
            {
                User u = new User();
                u.name = i + "_name";
                u.pwd = i + "_pwd";
                list.Add(u);
            }*/
            //设置表格控件的DataSource属性
            dataGridView1.DataSource = list;
            //设置数据表格上显示的列标题
            dataGridView1.Columns[0].HeaderText = "编号";
            dataGridView1.Columns[1].HeaderText = "课程名称";
            dataGridView1.RowHeadersVisible = false;
            //设置数据表格为只读
            dataGridView1.ReadOnly = true;
            //不允许添加行
            dataGridView1.AllowUserToAddRows = false;
            //背景为白色
            dataGridView1.BackgroundColor = System.Drawing.Color.White;
            //只允许选中单行
            dataGridView1.MultiSelect = false;
            //整行选中
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;

            
        }

        private void flushBtn_Click(object sender, EventArgs e)
        {
            list = manager.GetUsers();
            dataGridView1.DataSource = list;
        }

        private void dataGridView1_RowDividerDoubleClick(object sender, DataGridViewRowDividerDoubleClickEventArgs e)
        {
            MessageBox.Show("dataGridView1_RowDividerDoubleClick");
        }

        private void dataGridView1_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Console.WriteLine("+++++++++++++++++++++++++++++++++++++++");
            //CellDoubleClick
            // 取得当前单元格内容 
            Console.WriteLine(dataGridView1.CurrentCell.Value + "+++++++++++++++++++++++++++++++++++++++");
            MessageBox.Show(dataGridView1.CurrentCell.Value.ToString() + " ==>>> " + dataGridView1.CurrentCell.RowIndex);
            // 取得当前单元格的列 Index
            //Console.WriteLine(dataGridView1.CurrentCell.ColumnIndex);
            // 取得当前单元格的行 Index
            //Console.WriteLine(dataGridView1.CurrentCell.RowIndex);
            int index = e.RowIndex;
            this.dataGridView1.Rows[index].Cells[0].Value = "NewValue_" + index;
            this.dataGridView1.Rows[index].Cells[1].Value = "NewValueOf_" + index;
            //this.dataGridView1.Rows[index].Cells[2].Value = "监听";
        }
    }
}
