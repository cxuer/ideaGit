﻿using System;
using System.Windows.Forms;

namespace MyCores
{
    public partial class CoreForm : Core
    {
        public CoreForm()
        {
            InitializeComponent();
        }

        private void CoreForm_Load(object sender, EventArgs e)
        {
            Login frmLogin = new Login();
            frmLogin.Owner = this;
            this.Hide();
            frmLogin.ShowDialog();
            if (frmLogin.DialogResult != DialogResult.OK)
            {
                Application.ExitThread();
            }

        }
    }
}
