﻿using System;
using System.Windows.Forms;

namespace MyCores
{
    public partial class Login : Core
    {
        public Login()
        {
            InitializeComponent();
        }

        private void Login_Load(object sender, EventArgs e)
        {
            MaximizeBox = false;
            MinimizeBox = false;

        }
        int tryTimes = 5;
        private void btnLogin_Click(object sender, EventArgs e)
        {
            if (tryTimes > 1)
            {
                if (account.Text.Contains("swx") || passwd.Text.Contains("123"))
                {
                    Hide();
                    DialogResult = DialogResult.OK;
                }
                else
                {
                    MessageBox.Show("账号或密码错误，允许再尝试 " + (--tryTimes) + " 次！");
                    account.Focus();
                }
            }
            else
            {
                MessageBox.Show("尝试登录失败，请联系管理员重置账号！");
                Application.ExitThread();
            }

        }

        private void account_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                passwd.Focus();
            }

        }

        private void passwd_KeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Enter)
            {
                //btnLogin.Focus();
                btnLogin_KeyDown(sender, e);
            }
        }

        private void btnLogin_KeyDown(object sender, KeyEventArgs e)
        {
            btnLogin_Click(sender, e);
        }
    }
}
