﻿using System;
using System.Windows.Forms;

namespace MyCores
{
    public partial class FrmTest : Form
    {
        public FrmTest()
        {
            InitializeComponent();
        }

        private void FrmTest_Load(object sender, EventArgs e)
        {
            TreeNode tNode;
            tNode = treeView1.Nodes.Add("Websites");

            treeView1.Nodes[0].Nodes.Add("Net-informations.com");
            treeView1.Nodes[0].Nodes[0].Nodes.Add("CLR");

            treeView1.Nodes[0].Nodes.Add("Vb.net-informations.com");
            treeView1.Nodes[0].Nodes[1].Nodes.Add("String Tutorial");
            treeView1.Nodes[0].Nodes[1].Nodes.Add("Excel Tutorial");

            treeView1.Nodes[0].Nodes.Add("Csharp.net-informations.com");
            treeView1.Nodes[0].Nodes[2].Nodes.Add("ADO.NET");
            treeView1.Nodes[0].Nodes[2].Nodes[0].Nodes.Add("Dataset");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show(treeView1.SelectedNode.FullPath.ToString());
            MessageBox.Show(treeView1.SelectedNode.Text);
        }

        private void BindTreeView()
        {
            treeView1.LabelEdit = false;//不可编辑
                                        //添加结点
            TreeNode root = new TreeNode();
            root.Text = "根节点";
            //一级
            TreeNode node1 = new TreeNode();
            node1.Text = "1";
            TreeNode node2 = new TreeNode();
            node2.Text = "2";
            //二级
            TreeNode node11 = new TreeNode();
            node11.Text = "11";
            TreeNode node12 = new TreeNode();
            node12.Text = "12";
            TreeNode node21 = new TreeNode();
            node21.Text = "21";
            TreeNode node22 = new TreeNode();
            node22.Text = "22";
            //二级加入一级
            node1.Nodes.Add(node11);
            node1.Nodes.Add(node12);
            node2.Nodes.Add(node21);
            node2.Nodes.Add(node22);
            //一级加入根
            root.Nodes.Add(node1);
            root.Nodes.Add(node2);
            //
            treeView1.Nodes.Add(root);
        }
        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (treeView1.SelectedNode != null)
            {
                MessageBox.Show(treeView1.SelectedNode.Text);
            }
        }
    }
}
