﻿namespace MyCores
{
    partial class Core
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panelcontrol = new System.Windows.Forms.Panel();
            this.tabControls = new System.Windows.Forms.TabControl();
            this.CaseTabPage = new System.Windows.Forms.TabPage();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.TaskTabPage = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.checkBox2 = new System.Windows.Forms.CheckBox();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.label7 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.BugTabPage = new System.Windows.Forms.TabPage();
            this.import = new System.Windows.Forms.Button();
            this.bugGridView = new System.Windows.Forms.DataGridView();
            this.export = new System.Windows.Forms.Button();
            this.search = new System.Windows.Forms.Button();
            this.details = new System.Windows.Forms.TextBox();
            this.status = new System.Windows.Forms.ComboBox();
            this.module = new System.Windows.Forms.ComboBox();
            this.createDate = new System.Windows.Forms.DateTimePicker();
            this.creationDate = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.detail = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.AcceptancePage = new System.Windows.Forms.TabPage();
            this.panelcontrol.SuspendLayout();
            this.tabControls.SuspendLayout();
            this.CaseTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.TaskTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.BugTabPage.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bugGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // panelcontrol
            // 
            this.panelcontrol.Controls.Add(this.tabControls);
            this.panelcontrol.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelcontrol.Location = new System.Drawing.Point(0, 0);
            this.panelcontrol.Name = "panelcontrol";
            this.panelcontrol.Size = new System.Drawing.Size(2002, 1260);
            this.panelcontrol.TabIndex = 0;
            // 
            // tabControls
            // 
            this.tabControls.Controls.Add(this.CaseTabPage);
            this.tabControls.Controls.Add(this.TaskTabPage);
            this.tabControls.Controls.Add(this.BugTabPage);
            this.tabControls.Controls.Add(this.AcceptancePage);
            this.tabControls.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControls.HotTrack = true;
            this.tabControls.Location = new System.Drawing.Point(0, 0);
            this.tabControls.Name = "tabControls";
            this.tabControls.Padding = new System.Drawing.Point(14, 12);
            this.tabControls.SelectedIndex = 4;
            this.tabControls.Size = new System.Drawing.Size(2002, 1260);
            this.tabControls.TabIndex = 0;
            // 
            // CaseTabPage
            // 
            this.CaseTabPage.Controls.Add(this.dataGridView1);
            this.CaseTabPage.Controls.Add(this.button3);
            this.CaseTabPage.Controls.Add(this.button2);
            this.CaseTabPage.Controls.Add(this.button1);
            this.CaseTabPage.Controls.Add(this.textBox1);
            this.CaseTabPage.Controls.Add(this.label4);
            this.CaseTabPage.Controls.Add(this.dateTimePicker1);
            this.CaseTabPage.Controls.Add(this.comboBox2);
            this.CaseTabPage.Controls.Add(this.comboBox1);
            this.CaseTabPage.Controls.Add(this.label3);
            this.CaseTabPage.Controls.Add(this.label2);
            this.CaseTabPage.Controls.Add(this.label1);
            this.CaseTabPage.Location = new System.Drawing.Point(8, 61);
            this.CaseTabPage.Name = "CaseTabPage";
            this.CaseTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.CaseTabPage.Size = new System.Drawing.Size(1986, 1191);
            this.CaseTabPage.TabIndex = 0;
            this.CaseTabPage.Text = "测试用例";
            this.CaseTabPage.ToolTipText = "查询，导出，导入用例";
            this.CaseTabPage.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(3, 204);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 82;
            this.dataGridView1.Size = new System.Drawing.Size(1980, 983);
            this.dataGridView1.TabIndex = 11;
            this.dataGridView1.Text = "dataGridView1";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(1546, 105);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(150, 46);
            this.button3.TabIndex = 10;
            this.button3.Text = "button3";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(1334, 105);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(150, 46);
            this.button2.TabIndex = 9;
            this.button2.Text = "button2";
            this.button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(1124, 105);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(150, 46);
            this.button1.TabIndex = 8;
            this.button1.Text = "button1";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(226, 113);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(776, 38);
            this.textBox1.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(116, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 31);
            this.label4.TabIndex = 6;
            this.label4.Text = "label4";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Location = new System.Drawing.Point(1272, 31);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(424, 38);
            this.dateTimePicker1.TabIndex = 5;
            // 
            // comboBox2
            // 
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Location = new System.Drawing.Point(668, 38);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(338, 39);
            this.comboBox2.TabIndex = 4;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(226, 34);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(264, 39);
            this.comboBox1.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(1124, 31);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(82, 31);
            this.label3.TabIndex = 2;
            this.label3.Text = "label3";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(548, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "label2";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(116, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "label1";
            // 
            // TaskTabPage
            // 
            this.TaskTabPage.Controls.Add(this.dataGridView2);
            this.TaskTabPage.Controls.Add(this.button5);
            this.TaskTabPage.Controls.Add(this.button4);
            this.TaskTabPage.Controls.Add(this.checkBox2);
            this.TaskTabPage.Controls.Add(this.checkBox1);
            this.TaskTabPage.Controls.Add(this.label7);
            this.TaskTabPage.Controls.Add(this.comboBox4);
            this.TaskTabPage.Controls.Add(this.label6);
            this.TaskTabPage.Controls.Add(this.comboBox3);
            this.TaskTabPage.Controls.Add(this.label5);
            this.TaskTabPage.Location = new System.Drawing.Point(8, 61);
            this.TaskTabPage.Name = "TaskTabPage";
            this.TaskTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.TaskTabPage.Size = new System.Drawing.Size(1986, 1191);
            this.TaskTabPage.TabIndex = 1;
            this.TaskTabPage.Text = "任务管理";
            this.TaskTabPage.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(4, 190);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 82;
            this.dataGridView2.Size = new System.Drawing.Size(1979, 997);
            this.dataGridView2.TabIndex = 10;
            this.dataGridView2.Text = "dataGridView2";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(1370, 100);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(150, 46);
            this.button5.TabIndex = 9;
            this.button5.Text = "button5";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(1140, 100);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(150, 46);
            this.button4.TabIndex = 8;
            this.button4.Text = "button4";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // checkBox2
            // 
            this.checkBox2.AutoSize = true;
            this.checkBox2.Location = new System.Drawing.Point(1370, 43);
            this.checkBox2.Name = "checkBox2";
            this.checkBox2.Size = new System.Drawing.Size(168, 35);
            this.checkBox2.TabIndex = 6;
            this.checkBox2.Text = "checkBox2";
            this.checkBox2.UseVisualStyleBackColor = true;
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Location = new System.Drawing.Point(1140, 43);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(168, 35);
            this.checkBox1.TabIndex = 5;
            this.checkBox1.Text = "checkBox1";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(984, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(82, 31);
            this.label7.TabIndex = 4;
            this.label7.Text = "label7";
            // 
            // comboBox4
            // 
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Location = new System.Drawing.Point(252, 108);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(658, 39);
            this.comboBox4.TabIndex = 3;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(128, 108);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(82, 31);
            this.label6.TabIndex = 2;
            this.label6.Text = "label6";
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(252, 40);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(658, 39);
            this.comboBox3.TabIndex = 1;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(128, 43);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(82, 31);
            this.label5.TabIndex = 0;
            this.label5.Text = "label5";
            // 
            // BugTabPage
            // 
            this.BugTabPage.Controls.Add(this.import);
            this.BugTabPage.Controls.Add(this.bugGridView);
            this.BugTabPage.Controls.Add(this.export);
            this.BugTabPage.Controls.Add(this.search);
            this.BugTabPage.Controls.Add(this.details);
            this.BugTabPage.Controls.Add(this.status);
            this.BugTabPage.Controls.Add(this.module);
            this.BugTabPage.Controls.Add(this.createDate);
            this.BugTabPage.Controls.Add(this.creationDate);
            this.BugTabPage.Controls.Add(this.label10);
            this.BugTabPage.Controls.Add(this.detail);
            this.BugTabPage.Controls.Add(this.label8);
            this.BugTabPage.Location = new System.Drawing.Point(8, 61);
            this.BugTabPage.Name = "BugTabPage";
            this.BugTabPage.Padding = new System.Windows.Forms.Padding(3);
            this.BugTabPage.Size = new System.Drawing.Size(1986, 1191);
            this.BugTabPage.TabIndex = 2;
            this.BugTabPage.Text = "缺陷跟踪";
            this.BugTabPage.UseVisualStyleBackColor = true;
            // 
            // import
            // 
            this.import.Location = new System.Drawing.Point(1728, 108);
            this.import.Name = "import";
            this.import.Size = new System.Drawing.Size(150, 46);
            this.import.TabIndex = 13;
            this.import.Text = "导 入";
            this.import.UseVisualStyleBackColor = true;
            this.import.Click += new System.EventHandler(this.import_Click);
            // 
            // bugGridView
            // 
            this.bugGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.bugGridView.Location = new System.Drawing.Point(4, 200);
            this.bugGridView.Name = "bugGridView";
            this.bugGridView.RowHeadersWidth = 82;
            this.bugGridView.Size = new System.Drawing.Size(1978, 987);
            this.bugGridView.TabIndex = 12;
            this.bugGridView.Text = "dataGridView3";
            // 
            // export
            // 
            this.export.Location = new System.Drawing.Point(1540, 108);
            this.export.Name = "export";
            this.export.Size = new System.Drawing.Size(150, 46);
            this.export.TabIndex = 11;
            this.export.Text = "导 出";
            this.export.UseVisualStyleBackColor = true;
            this.export.Click += new System.EventHandler(this.export_Click);
            // 
            // search
            // 
            this.search.Location = new System.Drawing.Point(1352, 108);
            this.search.Name = "search";
            this.search.Size = new System.Drawing.Size(150, 46);
            this.search.TabIndex = 10;
            this.search.Text = "查 询";
            this.search.UseVisualStyleBackColor = true;
            this.search.Click += new System.EventHandler(this.search_Click);
            // 
            // details
            // 
            this.details.Location = new System.Drawing.Point(262, 113);
            this.details.Name = "details";
            this.details.Size = new System.Drawing.Size(1016, 38);
            this.details.TabIndex = 9;
            // 
            // status
            // 
            this.status.FormattingEnabled = true;
            this.status.Location = new System.Drawing.Point(1074, 42);
            this.status.Name = "status";
            this.status.Size = new System.Drawing.Size(204, 39);
            this.status.TabIndex = 8;
            // 
            // module
            // 
            this.module.FormattingEnabled = true;
            this.module.Location = new System.Drawing.Point(262, 45);
            this.module.Name = "module";
            this.module.Size = new System.Drawing.Size(256, 39);
            this.module.TabIndex = 7;
            // 
            // createDate
            // 
            this.createDate.Location = new System.Drawing.Point(1652, 39);
            this.createDate.Name = "createDate";
            this.createDate.Size = new System.Drawing.Size(226, 38);
            this.createDate.TabIndex = 6;
            // 
            // creationDate
            // 
            this.creationDate.AutoSize = true;
            this.creationDate.Location = new System.Drawing.Point(1536, 45);
            this.creationDate.Name = "creationDate";
            this.creationDate.Size = new System.Drawing.Size(110, 31);
            this.creationDate.TabIndex = 4;
            this.creationDate.Text = "创建日期";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1006, 42);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(62, 31);
            this.label10.TabIndex = 2;
            this.label10.Text = "状态";
            // 
            // detail
            // 
            this.detail.AutoSize = true;
            this.detail.Location = new System.Drawing.Point(138, 113);
            this.detail.Name = "detail";
            this.detail.Size = new System.Drawing.Size(110, 31);
            this.detail.TabIndex = 1;
            this.detail.Text = "缺陷描述";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(138, 48);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 31);
            this.label8.TabIndex = 0;
            this.label8.Text = "模块功能";
            // 
            // AcceptancePage
            // 
            this.AcceptancePage.Location = new System.Drawing.Point(8, 61);
            this.AcceptancePage.Name = "AcceptancePage";
            this.AcceptancePage.Padding = new System.Windows.Forms.Padding(3);
            this.AcceptancePage.Size = new System.Drawing.Size(1986, 1191);
            this.AcceptancePage.TabIndex = 3;
            this.AcceptancePage.Text = "用户验收";
            this.AcceptancePage.UseVisualStyleBackColor = true;
            // 
            // Core
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(2002, 1260);
            this.Controls.Add(this.panelcontrol);
            this.Name = "Core";
            this.Text = "Core";
            this.Load += new System.EventHandler(this.Core_Load);
            this.panelcontrol.ResumeLayout(false);
            this.tabControls.ResumeLayout(false);
            this.CaseTabPage.ResumeLayout(false);
            this.CaseTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.TaskTabPage.ResumeLayout(false);
            this.TaskTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.BugTabPage.ResumeLayout(false);
            this.BugTabPage.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bugGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panelcontrol;
        private System.Windows.Forms.TabControl tabControls;
        private System.Windows.Forms.TabPage CaseTabPage;
        private System.Windows.Forms.TabPage TaskTabPage;
        private System.Windows.Forms.TabPage BugTabPage;
        private System.Windows.Forms.TabPage AcceptancePage;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.CheckBox checkBox2;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.Label creationDate;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label detail;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Button export;
        private System.Windows.Forms.Button search;
        private System.Windows.Forms.TextBox details;
        private System.Windows.Forms.ComboBox status;
        private System.Windows.Forms.ComboBox module;
        private System.Windows.Forms.DateTimePicker createDate;
        private System.Windows.Forms.DataGridView bugGridView;
        private System.Windows.Forms.Button import;
        private System.Windows.Forms.Label cr;
    }
}