﻿namespace MyCores
{
    partial class BugFrm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.step = new System.Windows.Forms.RichTextBox();
            this.remark = new System.Windows.Forms.RichTextBox();
            this.module = new System.Windows.Forms.ComboBox();
            this.detail = new System.Windows.Forms.RichTextBox();
            this.category = new System.Windows.Forms.ComboBox();
            this.responsibleby = new System.Windows.Forms.TextBox();
            this.trackby = new System.Windows.Forms.TextBox();
            this.sit = new System.Windows.Forms.CheckBox();
            this.uat = new System.Windows.Forms.CheckBox();
            this.severity = new System.Windows.Forms.ComboBox();
            this.cancel = new System.Windows.Forms.Button();
            this.submmit = new System.Windows.Forms.Button();
            this.pro = new System.Windows.Forms.CheckBox();
            this.id = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(39, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 31);
            this.label1.TabIndex = 0;
            this.label1.Text = "缺陷描述";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(39, 182);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 31);
            this.label2.TabIndex = 1;
            this.label2.Text = "操作步骤";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(39, 492);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 31);
            this.label4.TabIndex = 3;
            this.label4.Text = "测试备注";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(39, 684);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(110, 31);
            this.label5.TabIndex = 4;
            this.label5.Text = "模块功能";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(523, 834);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(86, 31);
            this.label6.TabIndex = 5;
            this.label6.Text = "责任人";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(523, 762);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 31);
            this.label7.TabIndex = 6;
            this.label7.Text = "跟踪人";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(39, 759);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(110, 31);
            this.label8.TabIndex = 7;
            this.label8.Text = "缺陷类型";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(39, 834);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 31);
            this.label9.TabIndex = 8;
            this.label9.Text = "严重程度";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(499, 684);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 31);
            this.label10.TabIndex = 9;
            this.label10.Text = "测试环境";
            // 
            // step
            // 
            this.step.Location = new System.Drawing.Point(39, 221);
            this.step.Name = "step";
            this.step.Size = new System.Drawing.Size(994, 251);
            this.step.TabIndex = 11;
            this.step.Text = "";
            // 
            // remark
            // 
            this.remark.Location = new System.Drawing.Point(39, 526);
            this.remark.Name = "remark";
            this.remark.Size = new System.Drawing.Size(994, 123);
            this.remark.TabIndex = 13;
            this.remark.Text = "";
            // 
            // module
            // 
            this.module.FormattingEnabled = true;
            this.module.Location = new System.Drawing.Point(153, 681);
            this.module.Name = "module";
            this.module.Size = new System.Drawing.Size(298, 39);
            this.module.TabIndex = 14;
            this.module.MouseClick += new System.Windows.Forms.MouseEventHandler(this.module_MouseClick);
            // 
            // detail
            // 
            this.detail.Location = new System.Drawing.Point(40, 65);
            this.detail.Name = "detail";
            this.detail.Size = new System.Drawing.Size(994, 97);
            this.detail.TabIndex = 15;
            this.detail.Text = "";
            // 
            // category
            // 
            this.category.FormattingEnabled = true;
            this.category.Location = new System.Drawing.Point(153, 759);
            this.category.Name = "category";
            this.category.Size = new System.Drawing.Size(298, 39);
            this.category.TabIndex = 16;
            // 
            // responsibleby
            // 
            this.responsibleby.Location = new System.Drawing.Point(615, 834);
            this.responsibleby.Name = "responsibleby";
            this.responsibleby.Size = new System.Drawing.Size(418, 38);
            this.responsibleby.TabIndex = 17;
            // 
            // trackby
            // 
            this.trackby.Location = new System.Drawing.Point(615, 759);
            this.trackby.Name = "trackby";
            this.trackby.Size = new System.Drawing.Size(418, 38);
            this.trackby.TabIndex = 17;
            // 
            // sit
            // 
            this.sit.AutoSize = true;
            this.sit.Location = new System.Drawing.Point(615, 683);
            this.sit.Name = "sit";
            this.sit.Size = new System.Drawing.Size(81, 35);
            this.sit.TabIndex = 18;
            this.sit.Text = "SIT";
            this.sit.UseVisualStyleBackColor = true;
            // 
            // uat
            // 
            this.uat.AutoSize = true;
            this.uat.Location = new System.Drawing.Point(724, 683);
            this.uat.Name = "uat";
            this.uat.Size = new System.Drawing.Size(95, 35);
            this.uat.TabIndex = 19;
            this.uat.Text = "UAT";
            this.uat.UseVisualStyleBackColor = true;
            // 
            // severity
            // 
            this.severity.FormattingEnabled = true;
            this.severity.Location = new System.Drawing.Point(153, 831);
            this.severity.Name = "severity";
            this.severity.Size = new System.Drawing.Size(298, 39);
            this.severity.TabIndex = 20;
            // 
            // cancel
            // 
            this.cancel.Location = new System.Drawing.Point(301, 912);
            this.cancel.Name = "cancel";
            this.cancel.Size = new System.Drawing.Size(150, 46);
            this.cancel.TabIndex = 21;
            this.cancel.Text = "查 看";
            this.cancel.UseVisualStyleBackColor = true;
            this.cancel.Click += new System.EventHandler(this.cancel_Click);
            // 
            // submmit
            // 
            this.submmit.Location = new System.Drawing.Point(615, 912);
            this.submmit.Name = "submmit";
            this.submmit.Size = new System.Drawing.Size(150, 46);
            this.submmit.TabIndex = 22;
            this.submmit.Text = "提 交";
            this.submmit.UseVisualStyleBackColor = true;
            this.submmit.Click += new System.EventHandler(this.submmit_Click);
            // 
            // pro
            // 
            this.pro.AutoSize = true;
            this.pro.Location = new System.Drawing.Point(844, 683);
            this.pro.Name = "pro";
            this.pro.Size = new System.Drawing.Size(97, 35);
            this.pro.TabIndex = 23;
            this.pro.Text = "PRO";
            this.pro.UseVisualStyleBackColor = true;
            // 
            // id
            // 
            this.id.Location = new System.Drawing.Point(167, 917);
            this.id.Name = "id";
            this.id.Size = new System.Drawing.Size(128, 38);
            this.id.TabIndex = 24;
            // 
            // BugFrm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(14F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1082, 1046);
            this.Controls.Add(this.id);
            this.Controls.Add(this.pro);
            this.Controls.Add(this.submmit);
            this.Controls.Add(this.cancel);
            this.Controls.Add(this.severity);
            this.Controls.Add(this.uat);
            this.Controls.Add(this.sit);
            this.Controls.Add(this.trackby);
            this.Controls.Add(this.responsibleby);
            this.Controls.Add(this.category);
            this.Controls.Add(this.detail);
            this.Controls.Add(this.module);
            this.Controls.Add(this.remark);
            this.Controls.Add(this.step);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.MaximizeBox = false;
            this.Name = "BugFrm";
            this.Text = "BugFrm";
            this.Load += new System.EventHandler(this.BugFrm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.RichTextBox step;
        private System.Windows.Forms.RichTextBox remark;
        private System.Windows.Forms.ComboBox module;
        private System.Windows.Forms.RichTextBox detail;
        private System.Windows.Forms.ComboBox category;
        private System.Windows.Forms.TextBox responsibleby;
        private System.Windows.Forms.TextBox trackby;
        private System.Windows.Forms.CheckBox sit;
        private System.Windows.Forms.CheckBox uat;
        private System.Windows.Forms.ComboBox severity;
        private System.Windows.Forms.Button cancel;
        private System.Windows.Forms.Button submmit;
        private System.Windows.Forms.CheckBox pro;
        private System.Windows.Forms.TextBox id;
    }
}