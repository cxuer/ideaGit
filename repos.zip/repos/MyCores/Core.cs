﻿using BLL;
using MDL;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.IO;
using System.Windows.Forms;

namespace MyCores
{
    public partial class Core : Form
    {
        BugManage manage = new BugService();
        Bug bug = null;
        public Core()
        {
            this.StartPosition = FormStartPosition.CenterScreen;
            InitializeComponent();
        }

        private void button5_Click(object sender, System.EventArgs e)
        {

        }

        private void button3_Click(object sender, System.EventArgs e)
        {
            /*ExText ex = new ExText();
            //ex.test();
            ex.impTest();
            MessageBox.Show("操作成功。");*/

        }

        private void search_Click(object sender, System.EventArgs e)
        {
            bug = new Bug();
            bug.Module = module.Text;
            bug.Status = status.Text;
            bug.Detail = details.Text;
            bug.CreationDate = createDate.Value;

            //设置表格控件的DataSource属性
            bugGridView.DataSource = manage.search(bug);
            dataGridView1.RowHeadersVisible = false;
            //设置数据表格上显示的列标题
            /*bugGridView.Columns[0].HeaderText = "Detail";
            bugGridView.Columns[1].HeaderText = "Status";*/
            bugGridView.RowHeadersVisible = false;
            //设置数据表格为只读
            bugGridView.ReadOnly = true;
            //不允许添加行
            bugGridView.AllowUserToAddRows = false;
            //背景为白色
            //bugGridView.BackgroundColor = System.Drawing.Color.White;
            //只允许选中单行
            bugGridView.MultiSelect = false;
            //整行选中
            bugGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            //C#DataGridView 美化
            /*bugGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            bugGridView.AllowUserToAddRows = false;
            bugGridView.AllowUserToDeleteRows = false;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.LightCyan;
            bugGridView.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            bugGridView.BackgroundColor = System.Drawing.Color.White;
            bugGridView.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            bugGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;//211, 223, 240
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(211)))), ((int)(((byte)(223)))), ((int)(((byte)(240)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("宋体", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Navy;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            bugGridView.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            bugGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            bugGridView.EnableHeadersVisualStyles = false;
            bugGridView.GridColor = System.Drawing.SystemColors.GradientInactiveCaption;
            bugGridView.ReadOnly = true;
            bugGridView.RowHeadersVisible = false;
            bugGridView.RowTemplate.Height = 23;
            bugGridView.RowTemplate.ReadOnly = true;
            bugGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;*/
        }

        private void Core_Load(object sender, System.EventArgs e)
        {
            bugGridView.DataSource = manage.search(bug);
        }

        private void export_Click(object sender, System.EventArgs e)
        {
            FileInfo newFile = new FileInfo(@"D:\test.xlsx");
            if (newFile.Exists)
            {
                newFile.Delete();
            }
            List<Bug> bugs = manage.search(bug);

            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("缺陷清单");
                worksheet.Cells[1, 1].Value = "ID";
                worksheet.Cells[1, 2].Value = "缺陷描述";
                worksheet.Cells[1, 3].Value = "操作步骤";
                worksheet.Cells[1, 4].Value = "测试备注";
                worksheet.Cells[1, 5].Value = "状态";
                worksheet.Cells[1, 6].Value = "模块功能";
                worksheet.Cells[1, 7].Value = "严重程度";
                worksheet.Cells[1, 8].Value = "缺陷类型";
                worksheet.Cells[1, 9].Value = "测试环境";
                worksheet.Cells[1, 10].Value = "责任人";
                worksheet.Cells[1, 11].Value = "跟踪人";
                worksheet.Cells[1, 12].Value = "创建日期";
                worksheet.Cells[1, 13].Value = "关闭日期";
                int count = bugs.Count, j = 2;
                for (int i = 0; i < count; i++)
                {
                    worksheet.Cells[j, 1].Value = bugs[i].Id;
                    worksheet.Cells[j, 2].Value = bugs[i].Detail;
                    worksheet.Cells[j, 3].Value = bugs[i].Step;
                    worksheet.Cells[j, 4].Value = bugs[i].Remark;
                    worksheet.Cells[j, 5].Value = bugs[i].Status;
                    worksheet.Cells[j, 6].Value = bugs[i].Module;
                    worksheet.Cells[j, 7].Value = bugs[i].Severity;
                    worksheet.Cells[j, 8].Value = bugs[i].Category;
                    worksheet.Cells[j, 9].Value = bugs[i].Environment;
                    worksheet.Cells[j, 10].Value = bugs[i].ResponsibleBy;
                    worksheet.Cells[j, 11].Value = bugs[i].TrackBy;
                    worksheet.Cells[j, 12].Value = bugs[i].CreationDate.ToShortDateString();
                    worksheet.Cells[j, 13].Value = bugs[i].ClosingDate.ToShortDateString();
                    j++;
                }
                package.Save();

            }
            MessageBox.Show("导出成功 =>> " + newFile.FullName);
        }

        private void import_Click(object sender, System.EventArgs e)
        {
            List<Bug> bugs = new List<Bug>();
            FileInfo newFile = new FileInfo(@"D:\test.xlsx");
            if (!newFile.Exists)
            {
                MessageBox.Show("导入文件不存在！");
                return;
            }
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets["缺陷清单"];

                int rows = worksheet.Dimension.End.Row;
                if (rows > 501)
                {
                    MessageBox.Show("最多可一次性导入500条数据！");
                    return;
                }

                for (int i = 2; i <= rows; i++)
                {
                    Bug bug = new Bug();
                    //bug.Id = worksheet.Cells[i, 1].Value.ToString().Trim();
                    bug.Detail = worksheet.Cells[i, 2].Value.ToString().Trim();
                    bug.Step = worksheet.Cells[i, 3].Value.ToString().Trim();
                    bug.Remark = worksheet.Cells[i, 4].Value.ToString().Trim();
                    bug.Status = worksheet.Cells[i, 5].Value.ToString().Trim().ToUpper();
                    bug.Module = worksheet.Cells[i, 6].Value.ToString().Trim();
                    bug.Severity = worksheet.Cells[i, 7].Value.ToString().Trim();
                    bug.Category = worksheet.Cells[i, 8].Value.ToString().Trim();
                    bug.Environment = worksheet.Cells[i, 9].Value.ToString().Trim();
                    bug.ResponsibleBy = worksheet.Cells[i, 10].Value.ToString().Trim();
                    bug.TrackBy = worksheet.Cells[i, 11].Value.ToString().Trim();
                    bug.CreationDate = Convert.ToDateTime(worksheet.Cells[i, 12].Value.ToString().Trim());
                    bug.ClosingDate = Convert.ToDateTime(worksheet.Cells[i, 13].Value.ToString().Trim());
                    bug.CreationBy = "shiyc";
                    bugs.Add(bug);
                }
            }
            manage.import(bugs);
            MessageBox.Show("导入成功！");
        }
    }
}
