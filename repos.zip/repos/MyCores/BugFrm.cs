﻿using BLL;
using MDL;
using System;
using System.Windows.Forms;

namespace MyCores
{
    public partial class BugFrm : Form
    {
        private BugManage manage = null;

        private Bug bug = null;
        public BugFrm()
        {
            InitializeComponent();
            manage = new BugService();
        }

        private void BugFrm_Load(object sender, EventArgs e)
        {
            this.Text = "缺陷管理";
            module.Items.Add("登录");
            module.Items.Add("首页");
            module.SelectedText = "首页";

            severity.Items.Add("添加");
            severity.Items.Add("删除");
            severity.SelectedText = "删除";

            category.Items.Add("功能");
            category.Items.Add("性能");
            category.Items.Add("界面");
            category.SelectedText = "性能";
        }

        private void bugBuilder()
        {
            bug = new Bug();
            bug.Detail = detail.Text;
            bug.Step = step.Text;
            bug.Remark = remark.Text;
            bug.Status = "insert";
            bug.Module = module.Text;
            bug.Severity = severity.Text;
            bug.Category = category.Text;
            bug.ResponsibleBy = responsibleby.Text;
            bug.TrackBy = trackby.Text;
            bug.Environment = environmentText();
            bug.CreationBy = "shiyuchun";
            bug.CreationDate = DateTime.Now;
        }

        private void bugDetails()
        {
            detail.Text = bug.Detail;
            step.Text = bug.Step;
            remark.Text = bug.Remark;
            module.SelectedText = bug.Module;
            severity.SelectedText = bug.Severity;
            category.SelectedText = bug.Category;
            responsibleby.Text = bug.ResponsibleBy;
            trackby.Text = bug.TrackBy;
            if (bug.Environment.Contains("SIT"))
            {
                sit.Checked = true;
            }
            if (bug.Environment.Contains("UAT"))
            {
                uat.Checked = true;
            }
            if (bug.Environment.Contains("PRO"))
            {
                pro.Checked = true;
            }
        }

        private string environmentText()
        {
            string text = string.Empty;
            foreach (Control c in Controls)
            {
                if (c is CheckBox && ((CheckBox)c).Checked)
                {
                    text += ((CheckBox)c).Text + ",";
                }
            }
            if (text.EndsWith(","))
            {
                text = text.Substring(0, text.Length - 1);
            }
            return text;
        }

        private void cancel_Click(object sender, EventArgs e)
        {
            // this.Close();
            bug = manage.searchById(Convert.ToInt64(id.Text));
            bugDetails();
        }

        private void submmit_Click(object sender, EventArgs e)
        {
            bugBuilder();
            manage.save(bug);
            MessageBox.Show("提交成功");
        }

        private void module_MouseClick(object sender, MouseEventArgs e)
        {
            // 点击自动展开列表
            module.DroppedDown = true;
        }
    }
}
