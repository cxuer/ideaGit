﻿
using System.Configuration;
using Dapper;
using MySql.Data.MySqlClient;

namespace DDL
{
    public class DataCore
    {
        private static readonly string mySql = ConfigurationManager.ConnectionStrings["MySqlCon"].ConnectionString;
        private static readonly string mySqlite = ConfigurationManager.ConnectionStrings["sqlite"].ConnectionString;

        public static MySqlConnection MySqlConnection()
        {
            return new MySqlConnection(mySql);
        }
    }
}
