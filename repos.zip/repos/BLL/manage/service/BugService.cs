﻿using DAL;
using MDL;
using OfficeOpenXml;
using System.Collections.Generic;
using System.IO;

namespace BLL
{
    public class BugService : BugManage
    {
        private BugDao dao = new BugDaoImpl();

        List<Bug> bugs = null;
        public int save(Bug bug)
        {
            return dao.create(bug);
        }

        public int edit(Bug bug)
        {
            return dao.update(bug);
        }

        public int erase(long id)
        {
            return dao.delete(id);
        }

        public Bug searchById(long id)
        {
            return dao.findById(id);
        }

        public List<Bug> search(Bug bug)
        {
            return dao.find(bug);
        }

        public string export(Bug bug, FileInfo newFile)
        {
            newFile = new FileInfo(@"D:\test.xlsx");
            if (newFile.Exists)
            {
                newFile.Delete();
            }

            bugs = dao.export(bug);

            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("缺陷清单");
                worksheet.Cells[1, 1].Value = "缺陷描述";
                worksheet.Cells[1, 2].Value = "操作步骤";
                worksheet.Cells[1, 3].Value = "测试备注";
                worksheet.Cells[1, 4].Value = "状态";
                worksheet.Cells[1, 5].Value = "模块功能";
                worksheet.Cells[1, 6].Value = "严重程度";
                worksheet.Cells[1, 7].Value = "缺陷类型";
                worksheet.Cells[1, 8].Value = "测试环境";
                worksheet.Cells[1, 9].Value = "责任人";
                worksheet.Cells[1, 10].Value = "跟踪人";
                worksheet.Cells[1, 11].Value = "创建日期";
                worksheet.Cells[1, 12].Value = "关闭日期";
                int count = bugs.Count, j = 2;
                for (int i = 0; i < count; i++)
                {
                    worksheet.Cells[j, 1].Value = bugs[i].Detail;
                    worksheet.Cells[j, 2].Value = bugs[i].Step;
                    worksheet.Cells[j, 3].Value = bugs[i].Remark;
                    worksheet.Cells[j, 4].Value = bugs[i].Status;
                    worksheet.Cells[j, 5].Value = bugs[i].Module;
                    worksheet.Cells[j, 6].Value = bugs[i].Severity;
                    worksheet.Cells[j, 7].Value = bugs[i].Category;
                    worksheet.Cells[j, 8].Value = bugs[i].Environment;
                    worksheet.Cells[j, 9].Value = bugs[i].ResponsibleBy;
                    worksheet.Cells[j, 10].Value = bugs[i].TrackBy;
                    worksheet.Cells[j, 11].Value = bugs[i].CreationBy;
                    worksheet.Cells[j, 12].Value = bugs[i].ClosingDate;
                    j++;
                }
                package.Save();

            }
            return newFile.FullName;
        }

        public int import(List<Bug> bugs)
        {
            return dao.import(bugs);
        }
    }
}
