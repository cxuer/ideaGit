﻿using MDL;
using System.Collections.Generic;

namespace BLL
{
    public interface BugManage
    {
        public int save(Bug bug);

        public int edit(Bug bug);

        public int erase(long id);

        public Bug searchById(long id);

        public List<Bug> search(Bug bug);

        public int import(List<Bug> bugs);
    }
}
