﻿
using DAL;
using OfficeOpenXml;
using System.IO;

namespace BLL
{
    public class ExText
    {
        MysqlExt ex = new MysqlExt();

        public void dal()
        {
            ex.test();
        }
        public void test()
        {
            FileInfo newFile = new FileInfo(@"D:\test.xlsx");
            if (newFile.Exists)
            {
                newFile.Delete();
                //newFile = new FileInfo(@"D:\test.xlsx");
            }
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("test");
                //ExcelWorksheet worksheet = package.Workbook.Worksheets[1];//选定 指定页
                worksheet.Cells[1, 1].Value = "名称";
                worksheet.Cells[1, 2].Value = "价格";
                worksheet.Cells[1, 3].Value = "销量";

                worksheet.Cells[2, 1].Value = "大米";
                worksheet.Cells[2, 2].Value = 56;
                worksheet.Cells[2, 3].Value = 100;

                worksheet.Cells[3, 1].Value = "玉米";
                worksheet.Cells[3, 2].Value = 45;
                worksheet.Cells[3, 3].Value = 150;

                worksheet.Cells[4, 1].Value = "小米";
                worksheet.Cells[4, 2].Value = 38;
                worksheet.Cells[4, 3].Value = 130;

                worksheet.Cells[5, 1].Value = "白菜";
                worksheet.Cells[5, 2].Value = 22.33;
                worksheet.Cells[5, 3].Value = ex.test();

                package.Save();

            }
        }

        public void impTest()
        {
            FileInfo newFile = new FileInfo(@"D:\test.xlsx");
            if (!newFile.Exists)
            {
                return;
            }
            using (ExcelPackage package = new ExcelPackage(newFile))
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets["test"];//选定 指定页

                // 获取worksheet的行数
                int rows = worksheet.Dimension.End.Row;
                //获取worksheet的列数
                int cols = worksheet.Dimension.End.Column;

                string val = string.Empty;

                for (int i = 1; i <= rows; i++)
                {
                    for (int j = 1; j <= cols; j++)
                    {
                        val = worksheet.Cells[i, j].Value.ToString().Trim();
                    }
                }
            }

        }
    }
}
