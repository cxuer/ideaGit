﻿using System;

namespace MDL
{
    public class Suggest
    {
        public long Id { get; set; }
        public string Description { get; set; }
        public string Instruction { get; set; }
        public string Category { get; set; }
        public string Status { get; set; }
        public string CreationBy { get; set; }
        public DateTime CreationDate { get; set; }
        public string TrackBy { get; set; }
        public string ResponsibleBy { get; set; }
        public string Opinions { get; set; }
        public DateTime TreatDate { get; set; }
    }
}
