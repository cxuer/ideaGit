﻿using System;

namespace MDL
{
    public class Bug
    {
        public long Id { get; set; }
        public string Detail { get; set; }
        public string Step { get; set; }
        //public string Actual { get; set; }
        public string Remark { get; set; }
        public string CreationBy { get; set; }
        public string ResponsibleBy { get; set; }
        public string TrackBy { get; set; }
        public string Module { get; set; }
        public string Features { get; set; }
        public string Severity { get; set; }
        //public string Priority { get; set; }
        public string Environment { get; set; }
        public string Category { get; set; }
        public string Status { get; set; }
        public DateTime CreationDate { get; set; }
        //public DateTime ModifiedDate { get; set; }
        public DateTime ClosingDate { get; set; }

        /* 
        CREATE TABLE bug(
              id INT PRIMARY KEY AUTO_INCREMENT,
              DESCRIBE VARCHAR(512) NOT NULL,
              step VARCHAR(256),
              actual VARCHAR(256),
              STATUS VARCHAR(64),
              remark VARCHAR(512),
              module VARCHAR(64),
              features VARCHAR(64),
              severity VARCHAR(64),
              Environment VARCHAR(64),
              category VARCHAR(64),
              ResponsibleBy VARCHAR(32),
              trackby VARCHAR(32),
              creationby VARCHAR(32),
              CreationDate DATETIME,
              ModifiedDate DATETIME,
              closingdate DATETIME
             );
         */
    }
}
