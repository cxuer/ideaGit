﻿using System;

namespace MDL
{
    public class Case
    {
        public long Id { get; set; }
        public string Title { get; set; }
        public string Condition { get; set; }
        public string Data { get; set; }
        public string Steps { get; set; }
        public string Expected { get; set; }
        public string Module { get; set; }
        public string Feature { get; set; }
        public string Priority { get; set; }
        public string Category { get; set; }
        public string CreationBy { get; set; }
        public DateTime CreationDate { get; set; }
        public DateTime ModifiedDate { get; set; }

        /* 
        CREATE TABLE bug(
              id INT PRIMARY KEY AUTO_INCREMENT,
              DESCRIBE VARCHAR(512) NOT NULL,
              step VARCHAR(256),
              actual VARCHAR(256),
              STATUS VARCHAR(64),
              remark VARCHAR(512),
              module VARCHAR(64),
              features VARCHAR(64),
              severity VARCHAR(64),
              Environment VARCHAR(64),
              category VARCHAR(64),
              ResponsibleBy VARCHAR(32),
              trackby VARCHAR(32),
              creationby VARCHAR(32),
              CreationDate DATETIME,
              ModifiedDate DATETIME,
              closingdate DATETIME
             );
         */
    }
}
