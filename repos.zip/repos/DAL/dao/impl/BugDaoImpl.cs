﻿using Dapper;
using MDL;
using System.Collections.Generic;
using System.Linq;

namespace DAL
{
    public class BugDaoImpl : BugDao
    {
        public int create(Bug bug)
        {
            string insetSql = "INSERT INTO BUG(detail,step,status,remark,module,severity,category,environment,responsibleBy,trackby,creationby,creationDate) " +
                "VALUES(@Detail,@Step,@Status,@Remark,@Module,@Severity,@Category,@Environment,@ResponsibleBy,@Trackby,@Creationby,@CreationDate)";

            return MysqlExt.GetConnection().Execute(insetSql, bug);
        }

        public int update(Bug bug)
        {
            string updateSql = "UPDATE BUG SET detail=@detail,STEP=@STEP,ACTUAL=@ACTUAL,STATUS=@STATUS,REMARK=@REMARK WHERE ID=@ID";
            return MysqlExt.GetConnection().Execute(updateSql, bug);
        }

        public int delete(long id)
        {
            string deleteSql = "delete from bug where id=@id";
            return MysqlExt.GetConnection().Execute(deleteSql, new { id = id });
        }

        public List<Bug> find(Bug bug)
        {
            // id,detail,STATUS,module,severity,category,environment,responsibleBy,trackby,creationby,creationDate,closingDate
            string selectSql = "SELECT * FROM bug";
            if (bug != null)
            {
                selectSql += " where 1=1";
                var para = new DynamicParameters();
                if (!string.IsNullOrEmpty(bug.Module))
                {
                    selectSql += " and module = @Module";
                    para.Add("Module", bug.Module);
                }
                if (!string.IsNullOrEmpty(bug.Detail))
                {
                    selectSql += " and detail like @Detail";
                    para.Add("Detail", '%' + bug.Detail + '%');
                }
                if (!string.IsNullOrEmpty(bug.CreationDate.ToLongDateString()))
                {
                    selectSql += " and creationDate BETWEEN DATE_FORMAT(@CreationDate,'%Y-%m-%d') AND DATE_FORMAT(SYSDATE(),'%Y-%m-%d')";
                    para.Add("CreationDate", bug.CreationDate);
                }
                selectSql += " ORDER BY id DESC";
                return MysqlExt.GetConnection().Query<Bug>(selectSql, para).ToList();
            }
            selectSql += " ORDER BY id DESC";
            return MysqlExt.GetConnection().Query<Bug>(selectSql, bug).ToList();

        }

        public Bug findById(long id)
        {
            string selectSql = "select * from bug where id=@id";
            return MysqlExt.GetConnection().Query<Bug>(selectSql, new { id = id }).SingleOrDefault();
        }

        public int import(List<Bug> bugs)
        {
            string importSql = "INSERT INTO BUG(detail,step,status,remark,module,severity,category,environment,responsibleBy,trackby,creationby,creationDate,closingDate) " +
                "VALUES(@Detail,@Step,@Status,@Remark,@Module,@Severity,@Category,@Environment,@ResponsibleBy,@Trackby,@Creationby,@CreationDate,@ClosingDate)";
            return MysqlExt.GetConnection().Execute(importSql, bugs);
        }

        public List<Bug> export(Bug bug)
        {
            return find(bug);
        }

    }
}
