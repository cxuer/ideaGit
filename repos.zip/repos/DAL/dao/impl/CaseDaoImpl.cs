﻿namespace DAL
{
    public class CaseDaoImpl
    {
    }
}
