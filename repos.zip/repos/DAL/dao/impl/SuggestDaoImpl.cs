﻿namespace DAL
{
    class SuggestDaoImpl
    {
    }
}
