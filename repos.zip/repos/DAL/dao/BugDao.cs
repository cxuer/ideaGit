﻿using MDL;
using System.Collections.Generic;

namespace DAL
{
    public interface BugDao
    {
        public int create(Bug bug);

        public int update(Bug bug);

        public int delete(long id);

        public Bug findById(long id);

        public List<Bug> find(Bug bug);

        public List<Bug> export(Bug bug);

        public int import(List<Bug> bugs);

    }
}
