﻿using Dapper;
using MySql.Data.MySqlClient;
using System.Data;
using System.Linq;

namespace DAL
{
    public class MysqlExt
    {
        private static string ConnString = "Server=localhost;userid=shiyc;pwd=shiyc;port=3306;database=mydb;SslMode=none;";

        private static IDbConnection connection = null;

        public MysqlExt() { }

        public static IDbConnection GetConnection()
        {
            /*if (connection == null || connection.State == ConnectionState.Closed)
            {
                connection = new MySqlConnection(ConnString);
            }
            */
            return connection = new MySqlConnection(ConnString);
        }
        public string test()
        {
            // GetConnection().Query<string>("SELECT SYSDATE() FROM DUAL").SingleOrDefault();
            return GetConnection().Query<string>("SELECT SYSDATE() FROM DUAL").ToList().First();
        }

    }
}
