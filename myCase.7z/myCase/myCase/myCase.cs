﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using Excel = Microsoft.Office.Interop.Excel;

namespace myCase
{
    public partial class myCase : Form
    {
        int index = 0;
        List<Case> tmpcase;
        public myCase()
        {
            InitializeComponent();

        }

        public myCase(List<Case> mycase)
        {
            InitializeComponent();
            tmpcase = mycase;
        }

        private void nextCase_Click(object sender, EventArgs e)
        {
            if (index >= 0)
            {
                index = index + 1;
                showCase(index);
            }

        }

        private void beforCase_Click(object sender, EventArgs e)
        {
            if (index != 0)
            {
                index = index - 1;
                showCase(index);
            }
        }

        public void showCase(int idx)
        {
            if (tmpcase != null && idx < tmpcase.Count)
            {
                StringBuilder txt = new StringBuilder();
                txt.Append("【" + tmpcase[idx].getSL_Moduel() + "】");
                txt.Append(tmpcase[idx].getSummary().ToString() + "\n");
                txt.Append("【预置条件】" + "\n");
                txt.Append("【操作步骤】" + "\n");
                txt.Append(tmpcase[idx].getStep().ToString() + "\n");
                txt.Append("【预期结果】" + tmpcase[idx].getRestlt().ToString() + "\n");
                txt.Append("【实际结果】" + "\n");
                txt.Append("【测试备注】" + "\n");
                this.caseDesc.Text = txt.ToString();
                this.label1.Text = (index + 1).ToString() + "/" + tmpcase.Count;
            }
            else {
                StringBuilder txt = new StringBuilder();
                txt.Append("\n");
                txt.Append("Welcome to use myCase!" + "\n");
                txt.Append("*************************************************" + "\n");
                txt.Append("\n");
                txt.Append("There is no executable test case now." + "\n");
                txt.Append("Please import the test case," + "\n");
                txt.Append("according to the following steps." + "\n");
                txt.Append("myCase->ImpExcel" + "\n");
                this.caseDesc.Text = txt.ToString();
            }
        }

        private void myCase_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = true;            
            //this.TopLevel = true;
            this.BringToFront();
            this.TopMost = true;
            this.StartPosition = FormStartPosition.CenterParent;
            //tmpcase = new DataSource().dataCase();
            this.label1.Text = "";
            showCase(index);
        }

        private delegate List<Case> threadImpExcel(string str);

        //impExcel
        private void impExcelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog filelog = new OpenFileDialog();
            filelog.InitialDirectory = "D:\\";
            filelog.Filter = "Excel文件|*.xlsx";
            filelog.RestoreDirectory = true;
            filelog.FilterIndex = 1;
            if (filelog.ShowDialog() == DialogResult.OK)
            {
                threadImpExcel thread = ImpExcel;
                IAsyncResult r = thread.BeginInvoke(filelog.FileName,null,null);
                List<Case> impCase = thread.EndInvoke(r);

                //List<Case> impCase = ImpExcel(filelog.FileName);
                //MessageBox.Show("Import Excel of Case succussfully.");
                tmpcase = new List<Case>();
                tmpcase = impCase;
                index = 0;
                showCase(index);
                System.Diagnostics.Process[] ps = System.Diagnostics.Process.GetProcessesByName("EXCEL.EXE");
                foreach (System.Diagnostics.Process p in ps)
                {
                    p.Kill();
                }
            }            
        }

        //Exit
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //About myCase
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Version 1.04.12.2018 " + "\n" + "MyCase to Testing ");
        }

        public List<Case> ImpExcel(string filePath){            
            List<Case> excelRows = new List<Case>();
            //List<Case> tmpe = new List<Case>();
            Excel.Application excel = new Excel.Application();        
                excel.Visible = false;
                excel.DisplayAlerts = false;
                Excel.Workbook wb = excel.Workbooks.Open(filePath);
                //Excel.Worksheet ws = wb.Worksheets["测试用例"];
                Excel.Worksheet ws = (Excel.Worksheet)wb.Worksheets[1];
                //ws.Cells[1, 1] = "XXXXX"; //写值 
                Excel.Range range; 
                int rowCount = ws.UsedRange.Cells.Rows.Count;                               
                for (int i = 2; i < rowCount; i++) {
                    Case excelCase = new Case();
                        //FL_MO
                        range = ws.Cells[i, 2];
                        excelCase.setFL_Moduel(range.Text);
                        //SL_MO
                        range = ws.Cells[i, 3];
                        excelCase.setSL_Moduel(range.Text);
                        //FUN
                        range = ws.Cells[i, 4];
                        excelCase.setFN_Moduel(range.Text);
                        //Summary
                        range = ws.Cells[i, 6];
                        excelCase.setSummary(range.Text);
                        //Step
                        range = ws.Cells[i, 7];
                        excelCase.setStep(range.Text);
                        //Result
                        range = ws.Cells[i, 8];
                        excelCase.setRestlt(range.Text);
                        if (excelCase.getFL_Moduel().Length > 0) {
                            excelRows.Add(excelCase);
                        }
                        
                }
                //tmpe = excelRows;
                wb.Close();
                excel.Quit();
            return excelRows;
        }

        private const int OLDOFFICEVESION = -4143;
        private const int NEWOFFICEVESION = 56;

        public void exportToExcel(ArrayList dataArray, string filePath)
        {
            //保存excel文件的格式
            int FormatNum;
            //excel版本号
            string Version;
            //启动应用
            Excel.Application xlApp = new Excel.Application();

            System.Threading.Thread.CurrentThread.CurrentCulture = new System.Globalization.CultureInfo("en-US");
            Excel.Workbooks workbooks = xlApp.Workbooks;
            //创建文件
            Excel.Workbook workbook = workbooks.Add(Excel.XlWBATemplate.xlWBATWorksheet);
            //创建sheet
            Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Worksheets[1];
            //获取你使用的excel 的版本号
            Version = xlApp.Version;
            //使用Excel 97-2003
            if (Convert.ToDouble(Version) < 12)
            {
                FormatNum = OLDOFFICEVESION;
            }
            //使用 excel 2007或更新
            else
            {
                FormatNum = NEWOFFICEVESION;
            }
            //添加输出excel表格的表头信息信息
            //注意这里的excel对应的单元格第一个位置为[1,1]，而不是我们平时定义[0,0]
            ArrayList head = (ArrayList)dataArray[0];
            for (int i = 0; i < head.Count; i++)
            {
                worksheet.Cells[1, i + 1] = head[i].ToString();
                Excel.Range range = worksheet.Cells[1, 1];
                string tmep = range.Text;
            }
            //添加输出excel表格的内容信息
            for (int rowIndex = 1; rowIndex < dataArray.Count; rowIndex++)
            {
                ArrayList rowArr = (ArrayList)dataArray[rowIndex];
                for (int cellIndex = 0; cellIndex < rowArr.Count; cellIndex++)
                {
                    worksheet.Cells[rowIndex + 1, cellIndex + 1] = rowArr[cellIndex].ToString();
                }
            }
            //删除已存在的excel文件，否则会无法保存创建的excel文件
            if (File.Exists(filePath))
            {
                try
                {
                    File.Delete(filePath);
                }
                catch (IOException e)
                {
                    Console.WriteLine(e.Message);
                }
            }
            //保存，这里必须指定FormatNum文件的格式，否则无法打开创建的excel文件
            workbook.SaveAs(filePath);
            //显示创建的excel文件
            xlApp.Visible = true;
        }

        //测试函数
        public void test()
        {
            ArrayList perant = new ArrayList();
            ArrayList head = new ArrayList();
            head.Add("头部");
            perant.Add(head);
            ArrayList data = new ArrayList();
            data.Add("data");
            perant.Add(data);
            exportToExcel(perant, @"D:\testExcell.xlsx");
        }
    }
}

       
        

