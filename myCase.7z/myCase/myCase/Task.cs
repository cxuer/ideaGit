﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace myCase
{
    public class Task
    {
        int taskid;

        string taskname;

        List<Case> mycase;
        
        public Task(string taskname,List<Case> listcase) {
            this.taskid = new Random().Next(1, 30);
            this.taskname = taskname;
            this.mycase = listcase;
        }

        public string getTaskName()
        {
            return taskname;
        }

        public void setTaskName(string name)
        {
            taskname = name;
        }

        public int getTaskId()
        {
            return taskid;
        }

        public void setTaskId(int id)
        {
            taskid = id;
        }

        public List<Case> getMyCase()
        {
            return mycase;             
        }

         public void setMyCase(List<Case> listCase)
        {
            mycase = listCase;
        }
       
    }
}
