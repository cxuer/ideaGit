﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace myCase
{
    public class DataSource
    {
        public Task dataTask() {
           Task task = new Task("taskName", dataCase());
           return task;
        }

        public List<Case> dataCase() {
            //string[] temp = { "", "", "", "" };
            //List<string> t = new List<string>(temp);
            List<Case> data = new List<Case>();
            for (int i = 0; i < 10; i++ )
            {
                data.Add(new Case("人员管理", "人员轨迹", "人员轨迹", "人员轨迹页面选择人脸检索，不能导入不符合规格的头像图片并给予友好提示" + i, "1、打开人员轨迹页面2、点击检索类型下拉列表，选择人脸检索3、导入不符合规格的头像图片", "不能导入并给予友好提示" + i));
            }    
            return data;
        }
    }
}
