﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace myCase
{
    public class Case
    {
        string FL_Moduel;

        string SL_Moduel;

        string FN_Moduel;

        string Summary;

        string Step;

        string Restlt;

        int Id;

        public Case() { }
        
        public Case(string fL_Moduel, string sL_Moduel, string fN_Moduel, string summary,
                string step, string restlt)
        {
            FL_Moduel = fL_Moduel;
            SL_Moduel = sL_Moduel;
            FN_Moduel = fN_Moduel;            
            Summary = summary;
            Step = step;
            Restlt = restlt;
            Id = new Random().Next(1, 200);
        }

        public string getFL_Moduel()
        {
            return FL_Moduel;
        }

        public void setFL_Moduel(string fL_Moduel)
        {
            FL_Moduel = fL_Moduel;
        }

        public string getSL_Moduel()
        {
            return SL_Moduel;
        }

        public void setSL_Moduel(string sL_Moduel)
        {
            SL_Moduel = sL_Moduel;
        }

        public string getFN_Moduel()
        {
            return FN_Moduel;
        }

        public void setFN_Moduel(string fN_Moduel)
        {
            FN_Moduel = fN_Moduel;
        }

        public int getId()
        {
            return Id;
        }

        public void setId(int id)
        {
            Id = id;
        }

        public string getSummary()
        {
            return Summary;
        }

        public void setSummary(string summary)
        {
            Summary = summary;
        }

        public string getStep()
        {
            return Step;
        }

        public void setStep(string step)
        {
            Step = step;
        }

        public string getRestlt()
        {
            return Restlt;
        }

        public void setRestlt(string restlt)
        {
            Restlt = restlt;
        }

	

    }
}
