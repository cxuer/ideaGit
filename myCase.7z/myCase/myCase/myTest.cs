﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace myCase
{
    public partial class myTest : Form
    {
        Task tmptask = new DataSource().dataTask();
        public myTest()
        {
            InitializeComponent();
        }

        public myTest(Task mytask)
        {
            InitializeComponent();
            tmptask = new DataSource().dataTask();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tmptask == null)
            {
                MessageBox.Show("先创建测试任务","myCase");
            }
            else {
                new myCase(tmptask.getMyCase()).ShowDialog();
            }
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            new myTask().ShowDialog();
        }
    }
}
