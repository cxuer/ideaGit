﻿namespace myCase
{
    partial class myTest
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rsechTask = new System.Windows.Forms.Button();
            this.startTask = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.impCase = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // rsechTask
            // 
            this.rsechTask.Location = new System.Drawing.Point(271, 10);
            this.rsechTask.Name = "rsechTask";
            this.rsechTask.Size = new System.Drawing.Size(96, 22);
            this.rsechTask.TabIndex = 0;
            this.rsechTask.Text = "查询";
            this.rsechTask.UseVisualStyleBackColor = true;
            this.rsechTask.Click += new System.EventHandler(this.button1_Click);
            // 
            // startTask
            // 
            this.startTask.Location = new System.Drawing.Point(382, 10);
            this.startTask.Name = "startTask";
            this.startTask.Size = new System.Drawing.Size(96, 22);
            this.startTask.TabIndex = 1;
            this.startTask.Text = "执行";
            this.startTask.UseVisualStyleBackColor = true;
            this.startTask.Click += new System.EventHandler(this.button2_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(12, 40);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowTemplate.Height = 23;
            this.dataGridView1.Size = new System.Drawing.Size(605, 287);
            this.dataGridView1.TabIndex = 2;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(12, 12);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(253, 21);
            this.textBox1.TabIndex = 3;
            // 
            // impCase
            // 
            this.impCase.Location = new System.Drawing.Point(493, 10);
            this.impCase.Name = "impCase";
            this.impCase.Size = new System.Drawing.Size(96, 22);
            this.impCase.TabIndex = 4;
            this.impCase.Text = "导入";
            this.impCase.UseVisualStyleBackColor = true;
            this.impCase.Click += new System.EventHandler(this.button3_Click);
            // 
            // myTest
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(629, 339);
            this.Controls.Add(this.impCase);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.startTask);
            this.Controls.Add(this.rsechTask);
            this.Name = "myTest";
            this.Text = "myTest";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button rsechTask;
        private System.Windows.Forms.Button startTask;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button impCase;
    }
}